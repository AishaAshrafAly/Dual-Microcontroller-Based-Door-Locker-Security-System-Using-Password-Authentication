/*
 *  Created on: Nov 1, 2024
 *      Author: Aisha
 */

#ifndef PWM_H_
#define PWM_H_

#include "std_types.h"

void PWM_Timer0_Start(uint8 duty_cycle);

#endif /* PWM_H_ */
